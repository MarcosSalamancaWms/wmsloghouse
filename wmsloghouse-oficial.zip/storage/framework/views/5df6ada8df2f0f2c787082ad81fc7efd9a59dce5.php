<aside class="control-sidebar control-sidebar-<?php echo e(config('adminlte.right_sidebar_theme')); ?>">
    <?php echo $__env->yieldContent('right-sidebar'); ?>
</aside>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\vendor\jeroennoten\laravel-adminlte\resources\views\partials\sidebar\right-sidebar.blade.php ENDPATH**/ ?>