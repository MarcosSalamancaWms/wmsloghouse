<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <span class="h1">Tablero</span> <span class="ml-2 h6">Panel de Control</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\breadcrumbAdminlte::class, ['currentRoute' => 'Tablero']); ?>
<?php $component->withName('breadcrumb-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79)): ?>
<?php $component = $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79; ?>
<?php unset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="container-fluid">
        <div class="row">
             <?php if (isset($component)) { $__componentOriginal2af8810033e0959bb0cc6f00907e136db66e1ccf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\smallBoxsAdminlte\Ventas::class, ['ventaTotal' => '19,588']); ?>
<?php $component->withName('small-boxs-ventas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2af8810033e0959bb0cc6f00907e136db66e1ccf)): ?>
<?php $component = $__componentOriginal2af8810033e0959bb0cc6f00907e136db66e1ccf; ?>
<?php unset($__componentOriginal2af8810033e0959bb0cc6f00907e136db66e1ccf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal8d5ef84b0b0192d05c86fa46b52b844e656079c0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\smallBoxsAdminlte\Categorias::class, ['numeroCategorias' => '150']); ?>
<?php $component->withName('small-boxs-categorias'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal8d5ef84b0b0192d05c86fa46b52b844e656079c0)): ?>
<?php $component = $__componentOriginal8d5ef84b0b0192d05c86fa46b52b844e656079c0; ?>
<?php unset($__componentOriginal8d5ef84b0b0192d05c86fa46b52b844e656079c0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginalf9a695290de7bfdfafda7abf53939eaafe8f0a32 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\smallBoxsAdminlte\Clientes::class, ['numeroClientes' => '13']); ?>
<?php $component->withName('small-boxs-clientes'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf9a695290de7bfdfafda7abf53939eaafe8f0a32)): ?>
<?php $component = $__componentOriginalf9a695290de7bfdfafda7abf53939eaafe8f0a32; ?>
<?php unset($__componentOriginalf9a695290de7bfdfafda7abf53939eaafe8f0a32); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal81b6533ca260e5b57071a9d02ef06de9c2d235ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\smallBoxsAdminlte\Productos::class, ['numeroProductos' => '5,524']); ?>
<?php $component->withName('small-boxs-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal81b6533ca260e5b57071a9d02ef06de9c2d235ff)): ?>
<?php $component = $__componentOriginal81b6533ca260e5b57071a9d02ef06de9c2d235ff; ?>
<?php unset($__componentOriginal81b6533ca260e5b57071a9d02ef06de9c2d235ff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>


    </div>

    <div style="height: 1200px;">
        <p>Welcome to this beautiful admin panel.</p>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('footer'); ?>
         <?php if (isset($component)) { $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\FooterAdminlte::class, []); ?>
<?php $component->withName('footer-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732)): ?>
<?php $component = $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732; ?>
<?php unset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\home.blade.php ENDPATH**/ ?>