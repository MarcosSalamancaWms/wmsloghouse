<footer class="main-footer bg-dark">
    <?php echo $__env->yieldContent('footer'); ?>
</footer>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\vendor\jeroennoten\laravel-adminlte\resources\views\partials\footer\footer.blade.php ENDPATH**/ ?>