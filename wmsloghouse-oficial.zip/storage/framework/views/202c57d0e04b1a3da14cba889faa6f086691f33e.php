

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <span class="h1">Tablero</span> <span class="ml-2 h6">Panel de Control</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\breadcrumbAdminlte::class, ['currentRoute' => 'Resultados de Busqueda - Sistema WMS']); ?>
<?php $component->withName('breadcrumb-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79)): ?>
<?php $component = $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79; ?>
<?php unset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="container-fluid">
        <div class="row">

        </div>
    </div>

    <div style="height: 1200px;">
        <p>Welcome to this beautiful admin panel.</p>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('footer'); ?>
         <?php if (isset($component)) { $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\FooterAdminlte::class, []); ?>
<?php $component->withName('footer-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732)): ?>
<?php $component = $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732; ?>
<?php unset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="/css/admin_custom.css">

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\pages\search\search-wms.blade.php ENDPATH**/ ?>