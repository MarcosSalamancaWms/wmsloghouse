

<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Administrar Usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <hr class="mt-2">



    <?php if(isset($roles_user)): ?>


        <?php if(in_array('Administrador', $roles_user)): ?>

            
            <?php if(session('status')): ?>
                <script>
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Usuario Eliminado Correctamente',
                        showConfirmButton: false,
                        timer: 2000
                    })
                    setTimeout(function() {
                        location.reload();
                    }, 2000);

                </script>
            <?php endif; ?>

            
            <?php if(session('error-user')): ?>
                <script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Error al Eliminar el Usuario',
                        text: 'No puede Eliminarse a si mismo',
                    })

                </script>
            <?php endif; ?>

             <?php if (isset($component)) { $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\breadcrumbAdminlte::class, ['currentRoute' => 'Administrar Usuarios']); ?>
<?php $component->withName('breadcrumb-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79)): ?>
<?php $component = $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79; ?>
<?php unset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <div class="d-flex justify-content-start my-3">
                <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary btn-lg">Crear Nuevo Usuario <i
                        class="fas fa-user-plus mx-1"></i></a>
            </div>
             <?php if (isset($component)) { $__componentOriginalaf893c74811dd6885725a1f8e98f932a0e0f5b69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Users\TableUsers::class, ['userData' => $users]); ?>
<?php $component->withName('table-users'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaf893c74811dd6885725a1f8e98f932a0e0f5b69)): ?>
<?php $component = $__componentOriginalaf893c74811dd6885725a1f8e98f932a0e0f5b69; ?>
<?php unset($__componentOriginalaf893c74811dd6885725a1f8e98f932a0e0f5b69); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php else: ?>
             <?php if (isset($component)) { $__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NotPermission::class, []); ?>
<?php $component->withName('not-permission'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff)): ?>
<?php $component = $__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff; ?>
<?php unset($__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>


    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
     <?php if (isset($component)) { $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\FooterAdminlte::class, []); ?>
<?php $component->withName('footer-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732)): ?>
<?php $component = $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732; ?>
<?php unset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\pages\usuarios\ver-usuarios.blade.php ENDPATH**/ ?>