<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('adminlte_css_pre'); ?>
    
    <style>
        body {
            background-image: url('<?php echo e(asset('img/back.png')); ?>');
            background-size: cover;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php ($login_url = View::getSection('login_url') ?? config('adminlte.login_url', 'login')); ?>
    <?php ($register_url = View::getSection('register_url') ?? config('adminlte.register_url', 'register')); ?>
        <?php ($password_reset_url = View::getSection('password_reset_url') ?? config('adminlte.password_reset_url',
            'password/reset')); ?>

            <?php if(config('adminlte.use_route_url', false)): ?>
                <?php ($login_url = $login_url ? route($login_url) : ''); ?>
                    <?php ($register_url = $register_url ? route($register_url) : ''); ?>
                        <?php ($password_reset_url = $password_reset_url ? route($password_reset_url) : ''); ?>
                        <?php else: ?>
                            <?php ($login_url = $login_url ? url($login_url) : ''); ?>
                                <?php ($register_url = $register_url ? url($register_url) : ''); ?>
                                    <?php ($password_reset_url = $password_reset_url ? url($password_reset_url) : ''); ?>
                                    <?php endif; ?>

                                    <?php $__env->startSection('auth_header', __('Sign in to start your session')); ?>

                                    <?php $__env->startSection('auth_body'); ?>
                                        <form action="<?php echo e(route('login')); ?>" method="post" class="p-2">
                                            
                                            <?php echo csrf_field(); ?>

                                            <?php if($errors->has('estado')): ?>
                                                <?php if($errors->first('estado')): ?>
                                                    <script>
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Cuenta Desactivada',
                                                            text: '<?php echo e($errors->first('estado')); ?>',

                                                        })

                                                    </script>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            
                                            <div class="input-group mb-4">
                                                <input type="username" name="username" class="form-control <?php echo e($errors->has('username') ? 'is-invalid' : ''); ?>"
                                                    value="<?php echo e(old('username')); ?>" placeholder="<?php echo e(__('Username')); ?>" autofocus>
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fas fa-user <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                                                    </div>
                                                </div>
                                                <?php if($errors->has('username')): ?>
                                                    <div class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            
                                            <div class="input-group mb-4">
                                                <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>"
                                                    placeholder="<?php echo e(__('Password')); ?>">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fas fa-lock <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                                                    </div>
                                                </div>
                                                <?php if($errors->has('password')): ?>
                                                    <div class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            
                                            <div class="row">
                                                
                                                <div class="col-12">
                                                    <button type=submit
                                                        class="btn btn-block <?php echo e(config('adminlte.classes_auth_btn', 'btn-flat btn-primary')); ?>">
                                                        <span class="fas fa-sign-in-alt"></span>
                                                        <?php echo e(__('Sign In')); ?>

                                                    </button>
                                                </div>
                                            </div>

                                        </form>
                                    <?php $__env->stopSection(); ?>

                                    

<?php echo $__env->make('adminlte::auth.auth-page', ['auth_type' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\vendor\jeroennoten\laravel-adminlte\resources\views\auth\login.blade.php ENDPATH**/ ?>