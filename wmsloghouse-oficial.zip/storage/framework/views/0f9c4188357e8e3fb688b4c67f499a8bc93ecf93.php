<?php $__env->startSection('input_group_item'); ?>

    
    <input id="<?php echo e($id); ?>" name="<?php echo e($name); ?>"
        <?php echo e($attributes->merge(['class' => $makeItemClass()])); ?>>

<?php $__env->stopSection(true); ?>



<?php $__env->startPush('js'); ?>
<script>

    $(() => {

        // Create a method to set the addon color.

        let setAddonColor = function()
        {
            let color = $('#<?php echo e($id); ?>').data('colorpicker').getValue();

            $('#<?php echo e($id); ?>').closest('.input-group')
                .find('.input-group-text > i')
                .css('color', color);
        }

        // Init the plugin and register the change event listener.

        $('#<?php echo e($id); ?>').colorpicker( <?php echo json_encode($config, 15, 512) ?> )
            .on('change', setAddonColor);

        // Set the initial color for the addon.

        setAddonColor();
    })

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::components.form.input-group-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\vendor\jeroennoten\laravel-adminlte\resources\views\components\form\input-color.blade.php ENDPATH**/ ?>