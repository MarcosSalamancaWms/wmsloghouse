<div class="form-group">
    <label for="inputState"><?php echo e($text); ?></label>
    <select id="<?php echo e($reference); ?>" class="form-control border shadow rounded my-2" name="<?php echo e($reference); ?>">
        <?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($bodega->id); ?>"><?php echo e($bodega->bodega); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\components\bodegas-component.blade.php ENDPATH**/ ?>