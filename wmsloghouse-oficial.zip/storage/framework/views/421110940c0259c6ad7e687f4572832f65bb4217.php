<div>
    <label for="<?php echo e($referenceInput); ?>"><?php echo e($text); ?></label>
    <div class="input-group my-2 mr-sm-2">
        <div class="input-group-prepend">
            <div class="input-group-text">
                <i class="<?php echo e($classIcon); ?>"></i>
            </div>
        </div>
        <input type="<?php echo e($type); ?>" class="form-control shadow rounded" id="<?php echo e($referenceInput); ?>"
            name="<?php echo e($referenceInput); ?>" placeholder="<?php echo e($placeholder); ?>" value="<?php echo e($value); ?>">
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\components\input-group-form.blade.php ENDPATH**/ ?>