<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo-empresa.png')); ?>">
    <title>Laravel</title>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
</head>

<style>
    #app {
        background-image: url('<?php echo e(asset('img/back.png')); ?>');
        background-size: cover;
    }

    .navbar#menu,
    footer {
        box-shadow: 0 2px 4px -1px rgb(0 0 0 / 20%), 0 4px 5px 0 rgb(0 0 0 / 14%), 0 1px 10px 0 rgb(0 0 0 / 12%);
    }

</style>

<body>
    <div id="app">
         <?php if (isset($component)) { $__componentOriginalaad27af544a305167ad16e601288082f2ba07f89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\Navbar::class, ['color' => 'dark','nameApp' => ''.e(config('app.name')).'']); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaad27af544a305167ad16e601288082f2ba07f89)): ?>
<?php $component = $__componentOriginalaad27af544a305167ad16e601288082f2ba07f89; ?>
<?php unset($__componentOriginalaad27af544a305167ad16e601288082f2ba07f89); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

        <div class="container-fluid" style="height: 87vh !important;">
            <div class="d-flex justify-content-center align-items-center" style="height: 100%">
                <span>
                    <p class=" text-center display-4 font-weight-bold"><?php echo e(config('app.name')); ?></p>
                    <p class="text-center h4 font-weight-bold">Sistema de Inventario y Venta</p>
                    <div class="d-flex justify-content-center mt-3">
                        <?php if(auth()->guard()->check()): ?>

                            <a href="<?php echo e(route('home')); ?>" class="btn btn-dark text-white btn-lg rounded font-weight-bold">
                                Ir a Inicio
                            </a>

                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"
                                class="btn btn-dark text-white btn-lg rounded font-weight-bold">
                                Iniciar Sesión
                            </a>
                        <?php endif; ?>

                    </div>
                </span>
            </div>
        </div>

         <?php if (isset($component)) { $__componentOriginal5f31ebc5371028301b08b85941afca49d60361b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5f31ebc5371028301b08b85941afca49d60361b2)): ?>
<?php $component = $__componentOriginal5f31ebc5371028301b08b85941afca49d60361b2; ?>
<?php unset($__componentOriginal5f31ebc5371028301b08b85941afca49d60361b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    </div>

    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\welcome.blade.php ENDPATH**/ ?>