

<?php $__env->startSection('title', 'Editar Usuario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar al Usuario: <span class="h3"><?php echo e($usuario->username); ?></span></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($roles_user)): ?>
        <?php if(in_array('Administrador', $roles_user)): ?>
             <?php if (isset($component)) { $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\breadcrumbAdminlte::class, ['currentRoute' => 'Editar Usuario']); ?>
<?php $component->withName('breadcrumb-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79)): ?>
<?php $component = $__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79; ?>
<?php unset($__componentOriginal2fee1c07f569397b65c8f981562fd2f0ae3d9f79); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal95e665cb56a6e9731267abfe7813d3deb47b190c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorsValidate::class, []); ?>
<?php $component->withName('errors-validate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal95e665cb56a6e9731267abfe7813d3deb47b190c)): ?>
<?php $component = $__componentOriginal95e665cb56a6e9731267abfe7813d3deb47b190c; ?>
<?php unset($__componentOriginal95e665cb56a6e9731267abfe7813d3deb47b190c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php if(session('status')): ?>
                <script>
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Datos Actualizados Correctamente',
                        showConfirmButton: false,
                        timer: 2000
                    })
                    setTimeout(function() {
                        location.reload();
                    }, 2000);

                </script>
            <?php endif; ?>


            <div class="container">
                <form action="<?php echo e(route('user.update', $usuario->slug)); ?>" class="mt-3" method="POST"
                    id="form-update-data-user">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <p class="h4 font-weight-bold">Datos del Usuario</p>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                             <?php if (isset($component)) { $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\inputGroupForm::class, ['referenceInput' => 'nombre','text' => 'Nombre Completo','placeholder' => 'Escribe el nuevo Nombre Completo','classIcon' => 'fas fa-user-circle','type' => 'text','value' => ''.e(old('nombre', $usuario->profile->nombre)).'']); ?>
<?php $component->withName('input-group-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5)): ?>
<?php $component = $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5; ?>
<?php unset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-12 col-lg-3">
                             <?php if (isset($component)) { $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\inputGroupForm::class, ['referenceInput' => 'documento','text' => 'Documento','placeholder' => 'Escribe el nuevo Documento','classIcon' => 'fas fa-file-alt','type' => 'text','value' => ''.e(old('documento', $usuario->profile->documento)).'']); ?>
<?php $component->withName('input-group-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5)): ?>
<?php $component = $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5; ?>
<?php unset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-12 col-lg-3">
                            <div class="form-group">
                                <label for="inputState">Asignar Nueva Bodega:</label>
                                <select id="bodega" class="form-control border shadow rounded my-2" name="bodega">
                                    <?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($usuario->profile->bodega->id === $bodega->id): ?> selected <?php endif; ?> value="<?php echo e($bodega->id); ?>">
                                            <?php echo e($bodega->bodega); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <p class="h4 font-weight-bold">Datos de Acceso</p>
                    <div class="row">
                        <div class="col-12 col-md-5 col-lg-3">
                             <?php if (isset($component)) { $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\inputGroupForm::class, ['referenceInput' => 'username','text' => 'Nombre de Usuario','placeholder' => 'Escribe el nuevo Nombre de Usuario','classIcon' => 'fas fa-user','type' => 'text','value' => ''.e(old('username', $usuario->username)).'']); ?>
<?php $component->withName('input-group-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5)): ?>
<?php $component = $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5; ?>
<?php unset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-12 col-md-7 col-lg-4">
                             <?php if (isset($component)) { $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\inputGroupForm::class, ['referenceInput' => 'email','text' => 'Correo Electronico','placeholder' => 'Escribe el nuevo Correo Electronico','classIcon' => 'fas fa-envelope','type' => 'text','value' => ''.e(old('email', $usuario->email)).'']); ?>
<?php $component->withName('input-group-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5)): ?>
<?php $component = $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5; ?>
<?php unset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-12 col-md-12 col-lg-5">
                             <?php if (isset($component)) { $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\inputGroupForm::class, ['referenceInput' => 'password','text' => 'Contraseña','placeholder' => 'Escribe la nueva Contraseña','classIcon' => 'fas fa-lock','type' => 'password','value' => ''.e(old('password')).'']); ?>
<?php $component->withName('input-group-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5)): ?>
<?php $component = $__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5; ?>
<?php unset($__componentOriginal46d1d4cbee6929434a8f59b68858827ccfd212b5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                    <hr>
                    <div class="row my-4">
                        <div class="col-12 col-lg-12">
                            <p class="h4 font-weight-bold mb-3">Selecciona los Nuevos Roles del Usuario</p>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input"
                                        id="<?php echo e(str_replace(' ', '', $role->role_name)); ?>"
                                        name="<?php echo e(str_replace(' ', '', $role->role_name)); ?>" value="<?php echo e($role->id); ?>" <?php if(in_array($role->role_name, $roles_user_for_update)): ?> checked <?php endif; ?>>
                                    <label class="custom-control-label"
                                        for="<?php echo e(str_replace(' ', '', $role->role_name)); ?>"><?php echo e(str_replace(' ', '', $role->role_name)); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <label for="estado">Estado de la Cuenta:</label>
                                <select class="custom-select" name="estado" id="estado">
                                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($estado->id); ?>" <?php if($usuario->estado_id === $estado->id): ?> selected <?php endif; ?>><?php echo e($estado->estado); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <hr>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex justify-content-center">
                                <small class="text-info">* La imagen/foto de perfil, solamente podrá ser modificado por el
                                    usuario *</small>
                            </div>
                        </div>
                    </div>
                    <div class="row my-5">
                        <div class="col-12 d-flex justify-content-center">
                            <div class="mx-auto w-50">
                                <button type="submit" class="btn btn-primary btn-block shadow rounded font-weight-bold"
                                    id="btn-enviar-data-for-update-user">Guardar
                                    Cambios</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        <?php else: ?>
             <?php if (isset($component)) { $__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NotPermission::class, []); ?>
<?php $component->withName('not-permission'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff)): ?>
<?php $component = $__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff; ?>
<?php unset($__componentOriginalf8a65ba9e6cdc1cce32355dc43363c84c2ee4eff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
     <?php if (isset($component)) { $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\main\FooterAdminlte::class, []); ?>
<?php $component->withName('footer-adminlte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732)): ?>
<?php $component = $__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732; ?>
<?php unset($__componentOriginale007b2c3dae79acacd87918f2925af5da6e0d732); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        document.getElementById('btn-enviar-data-for-update-user').addEventListener('click', function(e) {
            e.preventDefault();

            let roles = [
                "Administrador",
                "Vendedor",
                "OperadordePiso",
                "Administrativo",
                "Supervisor"
            ];

            let result_one_role = false;

            roles.forEach(rol_refence => {

                if (document.getElementById(rol_refence).checked) {
                    result_one_role = true;
                }

            });

            if (result_one_role === true) {
                document.getElementById('form-update-data-user').submit();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Selecciona un rol...',
                    text: 'Por favor Selecciona al menos un rol o perfil para el usuario',
                })
            }
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\pages\usuarios\editar-usuarios.blade.php ENDPATH**/ ?>