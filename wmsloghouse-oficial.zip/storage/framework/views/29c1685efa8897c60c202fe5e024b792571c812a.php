<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Usuario</th>
            <th scope="col">Foto</th>
            <th scope="col">Perfil/Role</th>
            <th scope="col">Estado</th>
            <th scope="col">Último Inicio de Sesión</th>
            <th scope="col">Último Cierre de Sesión</th>
            <th scope="col">Acciones</th>
        </tr>
    </thead>
    <tbody>



        <?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->profile->nombre); ?></td>
                <td><?php echo e($user->username); ?></td>
                <td>
                    <img src="<?php echo e(asset($user->profile->photo->photo_url)); ?>" height="40" width="40" alt="">
                </td>
                <td>
                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($role->role_name); ?>, </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php if($user->estado_id === 1): ?>
                        <span class="badge badge-success"><?php echo e($user->estado->estado); ?></span>
                    <?php else: ?>
                        <span class="badge badge-danger"><?php echo e($user->estado->estado); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($user->last_session_started); ?></td>
                <td><?php echo e($user->last_session_completed); ?></td>
                <td>
                    <a href="<?php echo e(route('user.edit', $user->slug)); ?>" class="btn btn-warning btn-md mx-2">
                        <i class="fas fa-user-edit text-white"></i>
                    </a>
                    <button class="btn btn-danger btn-md mx-2" onclick="msjConfirmDeleteUser('<?php echo e($user->slug); ?>')">
                        <i class="fas fa-user-times text-white"></i>
                    </button>

                    <form action="<?php echo e(route('user.destroy', $user->slug)); ?>" method="POST"
                        id="form-delete-user-<?php echo e($user->slug); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </tbody>
</table>

<script>
    function msjConfirmDeleteUser(slug) {

        Swal.fire({
            title: '¿Estas Seguro de Eliminar a este Usuario?',
            text: "Esta acción no podrá ser revertida",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar'
        }).then((result) => {
            if (result.isConfirmed) {
                /* Si decide confimar la petición */

                document.getElementById(`form-delete-user-${slug}`).submit();

            }
        })
    }

</script>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\components\Users\table-users.blade.php ENDPATH**/ ?>