<?php if($errors->any()): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error al Procesar el Registro',
            text: 'Favor de verificar que los datos cumplan con los requerimientos',
        })

    </script>
    <div class="container shadow ronded border">
        <p class="text-center h3 font-weight-bold shadow p-3">Corregir los Siguientes Errores:</p>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <strong><?php echo e($error); ?></strong>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\components\errors-validate.blade.php ENDPATH**/ ?>