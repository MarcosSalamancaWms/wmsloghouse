  <div class="d-flex justify-content-end">

      <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><i class="fas fa-home mr-1"></i><a href="<?php echo e(route('home')); ?>">Inicio</a>
              </li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($current_route); ?></li>
          </ol>
      </nav>

  </div>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\components\main\breadcrumb-adminlte.blade.php ENDPATH**/ ?>