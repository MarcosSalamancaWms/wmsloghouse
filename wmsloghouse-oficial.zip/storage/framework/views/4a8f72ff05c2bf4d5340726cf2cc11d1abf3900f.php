<div class="container-fluid">
    <div>
        <strong> <?php echo e(config('app.name')); ?> </strong>
        Copyright © <script>
            document.write(new Date().getFullYear())

        </script>. All rights reserved.
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\sistemas\wmsloghouse-oficial\resources\views\components\main\footer-adminlte.blade.php ENDPATH**/ ?>