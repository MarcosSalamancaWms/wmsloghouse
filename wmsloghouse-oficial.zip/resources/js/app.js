import Swal from 'sweetalert2/dist/sweetalert2.js'

require('./bootstrap');

window.Swal = require('sweetalert2')