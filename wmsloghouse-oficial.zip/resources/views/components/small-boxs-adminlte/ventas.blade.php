<div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-info">
        <div class="inner">
            <h3>$ {{ $ventaTotal }}</h3>

            <p>Ventas</p>
        </div>
        <div class="icon">
            <i class="fas fa-donate"></i>
        </div>
        <a href="#" class="small-box-footer">Más Información <i class="fas fa-arrow-circle-right"></i></a>
    </div>
</div>
