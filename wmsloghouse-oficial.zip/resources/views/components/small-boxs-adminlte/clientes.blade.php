<div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-yellow">
        <div class="inner">
            <h3 class="text-white">{{ $numeroClientes }}</h3>

            <p class="text-white">Clientes</p>
        </div>
        <div class="icon">
            <i class="fas fa-user-plus"></i>
        </div>
        <a href="#" class="small-box-footer" style="color: white !important;">Más Información <i
                class="fas fa-arrow-circle-right text-white"></i></a>
    </div>
</div>
