<!-- ./col -->
<div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-danger">
        <div class="inner">
            <h3>{{ $numeroProductos }}</h3>

            <p>Productos</p>
        </div>
        <div class="icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <a href="#" class="small-box-footer">Más Información <i class="fas fa-arrow-circle-right"></i></a>
    </div>
</div>
<!-- ./col -->
