  <div class="d-flex justify-content-end">

      <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><i class="fas fa-home mr-1"></i><a href="{{ route('home') }}">Inicio</a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">{{ $current_route }}</li>
          </ol>
      </nav>

  </div>
