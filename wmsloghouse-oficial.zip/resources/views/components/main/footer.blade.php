<footer class="p-1">
    <div class="container-fluid bg-dark">
        <div class="mx-auto d-flex justify-content-center">
            <div class="p-3">
                <span class="text-white font-weight-bold" style="font-size: 17px;">{{ config('app.name') }} - </span>
                <span class="mr-2 text-white" style="font-size: 17px;">

                    <script>
                        document.write(new Date().getFullYear());

                    </script>
                </span>
            </div>
        </div>
    </div>
</footer>
