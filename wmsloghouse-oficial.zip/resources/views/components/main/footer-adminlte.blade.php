<div class="container-fluid">
    <div>
        <strong> {{ config('app.name') }} </strong>
        Copyright © <script>
            document.write(new Date().getFullYear())

        </script>. All rights reserved.
    </div>
</div>
