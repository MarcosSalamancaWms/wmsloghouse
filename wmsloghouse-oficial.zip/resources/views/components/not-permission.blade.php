<div class="container">
    <div class="d-flex justify-content-center my-3">
        <img src="https://media.giphy.com/media/l4FGDLkDkCnsKwdnq/giphy.gif" alt="">
    </div>
    <div class="alert alert-danger d-flex justify-content-center" role="alert">
        <strong class="h3">No tienes permisos para realizar esta accion</strong>
    </div>
</div>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Acceso Denegado!!',
        text: 'No tienes permiso para realizar esta acción',
    })

</script>
